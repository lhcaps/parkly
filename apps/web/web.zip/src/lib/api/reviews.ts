﻿import { apiFetch, buildQuery, postJson } from '@/lib/http/client'
import { isRecord } from '@/lib/http/errors'
import type { ManualAuditPayload, ReviewQueueRes } from '@/lib/contracts/reviews'
import type { ManualReviewActionResponse, ReviewQueueItem } from '@parkly/contracts'

export function getReviewQueue(params?: {
  siteCode?: string
  status?: 'OPEN' | 'CLAIMED' | 'RESOLVED' | 'CANCELLED'
  sessionId?: string
  plate?: string
  laneCode?: string
  q?: string
  from?: string
  to?: string
  limit?: number
}) {
  const qs = buildQuery(params)
  return apiFetch<ReviewQueueRes>(`/api/gate-review-queue${qs ? `?${qs}` : ''}`, undefined, (value) => {
    const row = isRecord(value) ? value : {}
    return {
      rows: Array.isArray(row.rows) ? row.rows.filter((item): item is ReviewQueueItem => isRecord(item)) : [],
    }
  })
}

export function claimReview(reviewId: string, body: ManualAuditPayload) {
  return postJson<ManualReviewActionResponse>(`/api/gate-review-queue/${encodeURIComponent(reviewId)}/claim`, body)
}

export function manualApproveSession(sessionId: string, body: ManualAuditPayload) {
  return postJson<ManualReviewActionResponse>(`/api/gate-sessions/${encodeURIComponent(sessionId)}/manual-approve`, body)
}

export function manualRejectSession(sessionId: string, body: ManualAuditPayload) {
  return postJson<ManualReviewActionResponse>(`/api/gate-sessions/${encodeURIComponent(sessionId)}/manual-reject`, body)
}

export function manualOpenBarrier(sessionId: string, body: ManualAuditPayload) {
  return postJson<ManualReviewActionResponse>(`/api/gate-sessions/${encodeURIComponent(sessionId)}/manual-open-barrier`, body)
}
